from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import pipeline
from fastapi.middleware.cors import CORSMiddleware
import logging

# Logging setup
logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Vibe Check API")

# Enable CORS (important for frontend later)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load HuggingFace zero-shot classification model
try:
    classifier = pipeline(
        "zero-shot-classification",
        model="facebook/bart-large-mnli"
    )
    logging.info("Model loaded successfully")
except Exception as e:
    logging.error(f"Model loading failed: {e}")
    classifier = None


# Request body schema
class Feedback(BaseModel):
    text: str


@app.get("/")
def health_check():
    return {"status": "Vibe Check Backend Running 🚀"}


@app.post("/analyze")
def analyze_feedback(feedback: Feedback):

    if not classifier:
        raise HTTPException(status_code=500, detail="Model not loaded")

    if not feedback.text.strip():
        raise HTTPException(status_code=400, detail="Feedback text cannot be empty")

    labels = ["Concern", "Appreciation", "Suggestion"]

    try:
        result = classifier(feedback.text, labels)

        return {
            "category": result["labels"][0],
            "confidence": round(float(result["scores"][0]), 3),
            "message": "Analysis successful"
        }

    except Exception as e:
        logging.error(f"Error during classification: {e}")
        raise HTTPException(status_code=500, detail="Classification failed")
